# Lumus Desk

Local desktop fork of OpenCode. Upstream: https://github.com/anomalyco/opencode
Base commit: 80d43eb7073da9b1763840eb2e1ba778064e2ee3

OpenCode's MIT license and copyright in LICENSE are preserved. This project is not an official OpenCode distribution.

First patch: independent desktop identity and data directories, a visible RU/EN switch, theme picker and light/dark button, Lumus palette. Upstream release publication endpoints removed. Not ready for distribution until tests and updater/telemetry audits finish. Brain/hands and command editor are not implemented yet.
