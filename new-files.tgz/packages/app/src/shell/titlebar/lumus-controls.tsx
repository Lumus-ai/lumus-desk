import { useLanguage } from "@/runtime/i18n/language"
import { useTheme } from "@opencode/ui/theme/context"
import "./lumus-controls.css"

export function LumusControls() {
  const language = useLanguage()
  const theme = useTheme()
  const russian = () => language.locale() === "ru"
  return (
    <div class="lumus-controls" data-lumus-controls>
      <span class="lumus-brand" title={russian() ? "Lumus Desk · на базе OpenCode" : "Lumus Desk · based on OpenCode"}>Lumus Desk</span>
      <button type="button" data-lumus-language onClick={() => language.setLocale(russian() ? "en" : "ru")}
        aria-label={russian() ? "Сменить язык на английский" : "Switch language to Russian"}>
        {russian() ? "RU → EN" : "EN → RU"}
      </button>
      <select data-lumus-theme aria-label={russian() ? "Тема" : "Theme"} value={theme.themeId()}
        onChange={(event) => theme.setTheme(event.currentTarget.value)}>
        <option value="oc-2">OpenCode</option>
        <option value="lumus">Lumus</option>
        <option value="tokyonight">Tokyonight</option>
        <option value="catppuccin">Catppuccin</option>
      </select>
      <button type="button" data-lumus-mode onClick={() => theme.setColorScheme(theme.mode() === "dark" ? "light" : "dark")}
        aria-label={russian() ? "Сменить светлую или тёмную тему" : "Toggle light or dark theme"}>
        {theme.mode() === "dark" ? (russian() ? "Светлая" : "Light") : (russian() ? "Тёмная" : "Dark")}
      </button>
    </div>
  )
}
